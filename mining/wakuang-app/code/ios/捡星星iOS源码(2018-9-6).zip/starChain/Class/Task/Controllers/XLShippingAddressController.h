//
//  XLShippingAddressController.h
//  starChain
//
//  Created by rlx on 2018/6/12.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLBaseController.h"

@interface XLShippingAddressController : XLBaseController

@end
