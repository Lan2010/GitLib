//
//  XLTaskController.h
//  starChain
//
//  Created by rlx on 2018/6/6.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLRefreshController.h"

@interface XLTaskController : XLRefreshController

@end
