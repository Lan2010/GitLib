//
//  XLTaskView.h
//  starChain
//
//  Created by rlx on 2018/7/6.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XLTaskModel;

@interface XLTaskView : UIView

@property (strong, nonatomic) XLTaskModel *model;


@end
