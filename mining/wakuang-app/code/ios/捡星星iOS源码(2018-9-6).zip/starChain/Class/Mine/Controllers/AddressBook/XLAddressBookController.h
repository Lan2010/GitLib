//
//  XLAddressBookController.h
//  starChain
//
//  Created by rlx on 2018/7/5.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLTableController.h"

@interface XLAddressBookController : XLTableController

@end
