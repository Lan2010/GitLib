//
//  XLGeneticDataController.h
//  starChain
//
//  Created by rlx on 2018/7/17.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLBaseController.h"

@interface XLGeneticDataController : XLBaseController

@end
