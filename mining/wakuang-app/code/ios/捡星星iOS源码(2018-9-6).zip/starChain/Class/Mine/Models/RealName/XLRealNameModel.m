//
//  XLRealNameModel.m
//  starChain
//
//  Created by rlx on 2018/6/16.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLRealNameModel.h"

@implementation XLRealNameModel

@end
