//
//  XLInvitationController.h
//  starChain
//
//  Created by rlx on 2018/6/14.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLBaseController.h"

@interface XLInvitationController : XLBaseController

@property (strong, nonatomic) NSDictionary *dataDict;

@property (assign, nonatomic) int rewardCount;

@end
