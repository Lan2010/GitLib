//
//  QHZWkWebController.h
//  qhz
//
//  Created by 夏铁军 on 17/2/18.
//  Copyright © 2017年 qhz. All rights reserved.
//

#import "XLBaseController.h"

@interface XLWkWebController : XLBaseController

- (void)loadWebPageWithTitle:(NSString *)title urlString:(NSString *)urlString;

@end

