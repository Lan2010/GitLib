//
//  XLMineStyleValue1Cell.h
//  starChain
//
//  Created by rlx on 2018/6/14.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XLMineStyleValue1Cell : UITableViewCell

@property (copy, nonatomic) NSDictionary *dict;


@end
