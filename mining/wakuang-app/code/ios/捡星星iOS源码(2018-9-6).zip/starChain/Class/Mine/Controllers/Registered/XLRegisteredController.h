//
//  XLRegisteredController.h
//  starChain
//
//  Created by rlx on 2018/6/11.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLBaseController.h"

@interface XLRegisteredController : XLBaseController

@property (assign, nonatomic) BOOL modalControllers;


@end
