//
//  XLPersonModel.h
//  starChain
//
//  Created by rlx on 2018/7/12.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XLPersonModel : NSObject

@property (copy, nonatomic) NSString *name;
@property (copy, nonatomic) NSString *phone;
@property (copy, nonatomic) NSString *state;

@end
