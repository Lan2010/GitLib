//
//  XLRecordingAnimationView.h
//  starChain
//
//  Created by rlx on 2018/6/20.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XLRecordingAnimationView : UIView

- (void)endAnimation;

- (void)starAnimation;

@end
