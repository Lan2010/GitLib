//
//  QHZRefreshHeader.h
//  qhz
//
//  Created by 夏铁军 on 17/2/9.
//  Copyright © 2017年 qhz. All rights reserved.
//

#import "MJRefreshHeader.h"

@interface XLRefreshHeader : MJRefreshHeader

@end

