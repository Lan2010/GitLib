//
//  QHZGuidePageView.h
//  qhz
//
//  Created by lei wei on 2017/5/24.
//  Copyright © 2017年 qhz. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QHZGuidePageView : UIView

+ (void)showGuidePage;

@end
