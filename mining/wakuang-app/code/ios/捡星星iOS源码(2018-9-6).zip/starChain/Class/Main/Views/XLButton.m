//
//  XLButton.m
//  starChain
//
//  Created by rlx on 2018/6/11.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLButton.h"

@implementation XLButton

- (void)setHighlighted:(BOOL)highlighted {}

@end


