//
//  XLStarRankingController.h
//  starChain
//
//  Created by rlx on 2018/7/7.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLRefreshController.h"

@interface XLStarRankingController : XLRefreshController

@end
