//
//  XLRankingContentView.h
//  starChain
//
//  Created by rlx on 2018/7/13.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XLStarRankingModel;

@interface XLRankingContentView : UIImageView

@property (strong, nonatomic) XLStarRankingModel *model;

@end
