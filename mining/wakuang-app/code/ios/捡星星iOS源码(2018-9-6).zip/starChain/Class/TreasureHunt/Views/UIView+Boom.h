//
//  UIView+Boom.h
//  粒子效果demo
//
//  Created by apple on 16/8/7.
//  Copyright © 2016年 雷晏. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (Boom)

- (void)boomComplete:(void (^)(void))complete;

@end
