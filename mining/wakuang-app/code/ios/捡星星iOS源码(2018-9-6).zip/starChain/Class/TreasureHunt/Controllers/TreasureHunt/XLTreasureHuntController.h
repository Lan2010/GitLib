//
//  XLTreasureHuntController.h
//  starChain
//
//  Created by rlx on 2018/6/6.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLBaseController.h"

@interface XLTreasureHuntController : XLBaseController

@end
