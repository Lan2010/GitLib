//
//  XLTreasureHuntHeader.h
//  starChain
//
//  Created by rlx on 2018/6/8.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XLExploreView.h"

@interface XLTreasureHuntHeader : UIView

@property (strong, nonatomic) XLExploreView *exploreView;


@end
