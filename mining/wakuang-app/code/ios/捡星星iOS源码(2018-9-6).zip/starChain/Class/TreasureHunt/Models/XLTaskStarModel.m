//
//  XLStarModel.m
//  starChain
//
//  Created by rlx on 2018/6/27.
//  Copyright © 2018年 rlx. All rights reserved.
//

#import "XLTaskStarModel.h"

@implementation XLAdvertisingStarModel

@end

@implementation XLTaskStarModel

@end
